export const settings = {
  MARVEL_API_PUBLIC_KEY: "6b945cea7609cabbd4d4b782ff6e72ef",
  MARVEL_API_PRIVATE_KEY: "655619f733d93fd4ac21a1c7649e191fade6fe20",
};
