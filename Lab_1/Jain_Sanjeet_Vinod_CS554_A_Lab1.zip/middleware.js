function configMiddleWares(app) {}

export default configMiddleWares;
