export const typeDefs = `#graphql
type Query {
  test(test: Int): Int
}

  `;
